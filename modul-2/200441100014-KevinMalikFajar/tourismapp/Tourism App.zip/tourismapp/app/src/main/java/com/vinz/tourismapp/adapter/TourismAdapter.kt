package com.vinz.tourismapp.adapter

class TourismAdapter {
}